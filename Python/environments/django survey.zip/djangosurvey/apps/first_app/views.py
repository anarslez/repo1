from django.shortcuts import render, HttpResponse, redirect

def index(request):
    return render(request,'first_app/index.html')
def user(request):
    if request.method == "POST":
        context = {
            'lang' : request.POST['lang'],
            'loc' : request.POST['loc'],
            'email' : request.POST['email'],
            'comment' : request.POST['comment'],
        }
        request.session['context'] = context
        return redirect("/result")
    else:
        return redirect("/")
def result(request):
    context = request.session['context']
    return render(request,'first_app/show.html', context)