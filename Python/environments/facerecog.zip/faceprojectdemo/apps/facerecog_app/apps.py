from django.apps import AppConfig


class FacerecogAppConfig(AppConfig):
    name = 'facerecog_app'
