import cv2
import sys
import imutils
import math
import base64

# Get user supplied values
with open(sys.argv[1], "rb") as image_file:
    encoded_string = base64.b64encode(image_file.read())
with open("face.jpeg", "wb") as fh:
    fh.write(base64.b64decode(encoded_string))
imagePath = "face.jpeg"
image = cv2.imread(imagePath)
image = imutils.resize(image, width=600)

# Create the haar cascade
faceCascade = cv2.CascadeClassifier("haarcascade_frontalface_alt.xml")
eyeCascade = cv2.CascadeClassifier('haarcascade_eye.xml')
smileCascade = cv2.CascadeClassifier('haarcascade_smile.xml')

# Read the image
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Detect faces in the image
faces = faceCascade.detectMultiScale(
    gray,
    scaleFactor=1.5,
    minNeighbors=5,
    minSize=(20, 20),
    maxSize = (400, 400)
)


print("Found {0} faces!".format(len(faces)), faces)

# Draw a rectangle around the faces
for (x, y, w, h) in faces:
    cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)
    print('FACE',x, "left",y, "top",x+w, "right",y+h,"bottom",w,h)
    fwid=w
    roi_gray = gray[y:y+h, x:x+w]
    roi_color = image[y:y+h, x:x+w]
    eyes = eyeCascade.detectMultiScale(
        roi_gray,
        scaleFactor=1.01,
        minNeighbors=5,
        minSize=(48, 48),
        maxSize=(65, 65)
    )
    hairline = 0
    ebot = 0
    eyewid = []
    for (ex,ey,ew,eh) in eyes:
        cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,0,255),2)
        print('EYE', "left", ex, "top", ey, "right", ex+ew,"bottom", ey+eh, "width", ew, "height", eh)
        hairline = hairline+ey+eh/2
        ebot = ebot + (ey+eh)/2
        eyewid = eyewid+[ex]
        eyewid = eyewid+[ex+ew]
    smiles = smileCascade.detectMultiScale(
        roi_gray,
        scaleFactor=1.2,
        minNeighbors=5,
        minSize=(50, 130),
        maxSize=(100, 200)
    )
    for (ex,ey,ew,eh) in smiles:
        cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(255,0,0),2)
        mwid=ew
        mtop=ey
        mbot=ey+eh
        mleft = ex
        mright = ex+ew
        print('MOUTH', "left", ex, "top", ey, "right", ex+ew, "bottom", ey+eh, "width", ew ,"height", eh)

#calculations
mofa = mwid/fwid
chinheight = fwid-mbot
hairline = hairline/2
hairtomouth1 = math.atan((mleft-eyewid[0])/(mbot-hairline))*180/math.pi
hairtomouth2 = math.atan((eyewid[3]-mright)/(mbot-hairline))*180/math.pi
chinhypo = (chinheight**2+(mwid/2)**2)**0.5
chinangle = 180 - 2*math.asin(chinheight/chinhypo)*180/math.pi
hairangle = (hairtomouth1+hairtomouth2)/2
print(mofa, chinangle, hairangle,eyewid)

#shape classifier
if (hairangle>16 or hairangle<-16):
    if (chinangle<110):
        shape = 'heart'
    else:
        shape = 'round'
if (hairangle<=16 and hairangle>=-16):
    if (chinangle<110):
        shape = 'diamond'
    else:
        if(mofa<0.4):
            shape = 'oval'
        else:
            shape = 'square'

print(shape)
cv2.imshow("Faces found", image)
cv2.waitKey(0)
# cv2.imwrite('face.jpeg',image)