namespace dojosurvey.Models
    {
        public class Response
    	{
            public string email {get;set;}
            public string loc {get;set;}
            public string lang {get;set;}
            public string com {get;set;}

    	}
        
    }