using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
namespace dojosurvey.Controllers     //be sure to use your own project's namespace!
{
    public class SurveyController : Controller   //remember inheritance??
    {
        //for each route this controller is to handle:
        [HttpGet]       //type of request
        [Route("")]     //associated route string (exclude the leading /)
        public IActionResult Index()
        {
            return View("Index");
        }
        [HttpPost]
        [Route("method")]
        public IActionResult Method(string email, string loc, string lang, string com)
        {
            return RedirectToAction("result", new { email = email, loc = loc, lang = lang, com = com});
        }
        [HttpGet]       //type of request
        [Route("result")]     //associated route string (exclude the leading /)
        public IActionResult result(string email, string loc, string lang, string com)
        {
            ViewBag.com = com;
            ViewBag.lang = lang;
            ViewBag.loc = loc;
            ViewBag.email = email;
            return View("Show");
        }
    }
}