namespace viewmodel.Models
{
    public class Name
    	{
            public string[] nam {get;set;}

    	}
}