namespace viewmodel.Models
    {
        public class Message
    	{
            public string mess {get;set;}

    	}
        
    }