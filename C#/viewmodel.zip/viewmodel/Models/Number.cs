namespace viewmodel.Models
{
    public class Number
    	{
            public int[] num {get;set;}

    	}
}