﻿using System;

namespace human
{
    class Human
    {
        public int strength;
        public int intellegence;
        public int dexterity;
        public int health;
        public string name;
        public Human(string passname)
        {
            name = passname;
            strength = 3;
            intellegence = 3;
            dexterity = 3;
            health = 100;
        }
        public Human(string passname, int str, int intl, int dxt, int hlth)
        {
            name = passname;
            strength = str;
            intellegence = intl;
            dexterity = dxt;
            health = hlth;
        }
        public void attack(object human)
        {
            if (human is Human){
                var attacked = (Human)human;
                attacked.health = attacked.health - 5* strength;  
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
