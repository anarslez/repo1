using System;

namespace phone
{
    interface IRingable
    {
        string Ring();
        string Unlock();
    }
}