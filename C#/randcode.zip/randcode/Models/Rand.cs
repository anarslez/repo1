using System.ComponentModel.DataAnnotations;
namespace randcode.Models
    {
        public class Rand
        {
            public string finalString { get; set; }

    	}
        
    }